import boto3
from botocore.exceptions import ClientError

def lambda_handler(event, context):
    glue = boto3.client('glue')
    crawler_name = 'embedding_data_crawler'
    dbName = 'music_db'
    crawler_role = 'GlueCrawlerFromS3Role'

    # Check if database exists
    try:
        glue.get_database(Name=dbName)
        print(f"✅Database '{dbName}' already exists.")
    except ClientError as e:
        if e.response['Error']['Code'] == 'EntityNotFoundException':
            # Create database
            glue.create_database(
                DatabaseInput={
                    'Name': dbName,
                    'Description': 'Database for music datasets: user_data and user_top_artists'
                }
            )
            print(f"✅Database '{dbName}' created.")
        else:
            raise

    #check if crawler exists
    try:
        response = glue.get_crawler(Name=crawler_name)
        print(f"✅Crawler '{crawler_name}' already exists.")

    except ClientError as e:
        if e.response['Error']['Code'] == 'EntityNotFoundException':
            print(f"Crawler '{crawler_name}' does not exist. Creating...")
            response = glue.create_crawler(
                Name=crawler_name,
                Role=crawler_role,
                DatabaseName=dbName,
                Targets={
                    'S3Targets': [
                        {'Path': 's3://term-project3280/processed_parquet/user_embedding/'}, #creates processed_parquet_user_embedding_data table
                    ]
                },
                TablePrefix='processed_parquet_'
            )
            print("✅Crawler created:", response)
        else:
            raise

    #run the crawler
    response = glue.start_crawler(Name=crawler_name)
    print("Crawler started:", response)
    print("✅successfully finished.")