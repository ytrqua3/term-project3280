import json
import boto3
import time
import uuid

athena = boto3.client("athena")
s3 = boto3.client("s3")

def lambda_handler(event, context):
    print("(✅received api request to query data...)")
    try:
        body = json.loads(event.get("body", "{}"))
        query = body.get("query")

        if not query:
            print("❌query content is empty")
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Missing query in POST body"})
            }

        query_execution_id = str(uuid.uuid4())
        print("✅Starting athena query execution")
        response = athena.start_query_execution(
            QueryString=query,
            QueryExecutionContext={"Database": "music_db"},
            ResultConfiguration={
                "OutputLocation": f"s3://term-project3280/athena_results/{query_execution_id}/"
            }
        )

        execution_id = response["QueryExecutionId"]

        while True:
            print("Waiting for query to complete...")
            status = athena.get_query_execution(QueryExecutionId=execution_id)
            state = status["QueryExecution"]["Status"]["State"]

            if state in ["SUCCEEDED", "FAILED", "CANCELLED"]:
                break

            time.sleep(0.5)

        if state != "SUCCEEDED":
            print(f"❌Failed to query, status: {state}")
            return {
                "statusCode": 500,
                "body": json.dumps({"error": "Query failed"})
            }
        
        print("✅Query is successful!")
        result_response = athena.get_query_results(QueryExecutionId=execution_id)
        print("✅Got query results!")

        # Safely extract headers
        rows = result_response.get("ResultSet", {}).get("Rows", [])
        if not rows:
            print("⚠️ No data returned from query.")
            data = []
        else:
            header_row = rows[0].get("Data", [])
            headers = [col.get("VarCharValue", "") for col in header_row]

            data = []
            for row in rows[1:]:
                row_data = row.get("Data", [])
                values = [col.get("VarCharValue", None) for col in row_data]
                if len(values) < len(headers):
                    values.extend([None] * (len(headers) - len(values)))
                data.append(dict(zip(headers, values)))

        print("✅responding to api user")
        return {
            "statusCode": 200,
            "body": json.dumps(data)
        }

    except Exception as e:
        print(f"❌Exception occurred: {e}")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
