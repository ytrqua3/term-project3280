import json
import boto3

def lambda_handler(event, context):
    glue = boto3.client("glue")
    glue_job_name = 'aggregate_data'

    try:
        print(f"✅Starting Glue job: {glue_job_name}")

        response = glue.start_job_run(
            JobName=glue_job_name
        )

        job_run_id = response["JobRunId"]
        print(f"✅Started Glue JobRunId: {job_run_id}")


    except Exception as e:
        print(f"❌Error starting Glue job: {str(e)}")
        return {
            "statusCode": 500,
            "body": f"Error: {str(e)}"
        }

