import boto3
from botocore.exceptions import ClientError

def lambda_handler(event, context):
    glue = boto3.client('glue')
    crawler_name = 'processed_data_crawler'
    dbName = 'music_db'
    crawler_role = 'GlueCrawlerFromS3Role'

    # Check if database exists
    try:
        glue.get_database(Name=dbName)
        print(f"✅Database '{dbName}' already exists.")
    except ClientError as e:
        if e.response['Error']['Code'] == 'EntityNotFoundException':
            # Create database
            glue.create_database(
                DatabaseInput={
                    'Name': dbName,
                    'Description': 'Database for music datasets: user_data and user_top_artists'
                }
            )
            print(f"✅Database '{dbName}' created.")
        else:
            raise

    #check if crawler exists
    try:
        response = glue.get_crawler(Name=crawler_name)
        print(f"✅Crawler '{crawler_name}' already exists.")
        crawler_status = response['Crawler']['State']
        if crawler_status == 'RUNNING':
            print("Crawler is already running. Exit lambda now.")
            return

    except ClientError as e:
        if e.response['Error']['Code'] == 'EntityNotFoundException':
            print(f"Crawler '{crawler_name}' does not exist. Creating...")
            response = glue.create_crawler(
                Name=crawler_name,
                Role=crawler_role,
                DatabaseName=dbName,
                Targets={
                    'S3Targets': [
                        {'Path': 's3://term-project3280/processed_parquet/artist_rank_in_country/'},
                        {'Path': 's3://term-project3280/processed_parquet/country_rank_per_artist/'}
                    ]
                },
                TablePrefix='processed_parquet_'
            )
            print("✅Crawler created:", response)
        else:
            raise

    #run the crawler
    response = glue.start_crawler(Name=crawler_name)
    print("Crawler started:", response)
    print("✅successfully finished.")

    #delete _RUN_COMPLETE file
    response = s3.list_objects_v2(Bucket='term-project3280', Prefix='processed_parquet/_RUN_COMPLETE/')
    if 'Contents' in response:
        for obj in response['Contents']:
            s3.delete_object(Bucket=bucket, Key=obj['Key'])
    print("_RUN_COMPLETE deleted successfully")