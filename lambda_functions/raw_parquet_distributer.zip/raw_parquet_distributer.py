import boto3
import json

lambda_client = boto3.client("lambda")

def lambda_handler(event, context):
    lambda_client.invoke(
        FunctionName="createCrawlerForMusicData",
        InvocationType="Event",
        Payload=json.dumps(event)
    )

    lambda_client.invoke(
        FunctionName="start_aggregate_glue",
        InvocationType="Event",
        Payload=json.dumps(event)
    )

    print("✅Invokeded createCrawlerForMusicData and start_aggregate_glue lambda functions!")
    return {
        "statusCode": 200,
        "body": "Invoked createCrawlerForMusicData and start_aggregate_glue lambda functions!"
    }
