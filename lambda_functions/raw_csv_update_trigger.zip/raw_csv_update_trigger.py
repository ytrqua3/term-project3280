import boto3

def lambda_handler(event, context):
    glue = boto3.client("glue")
    glue_job_name = 'music_csv_to_parquet'

    s3 = boto3.client('s3')
    bucket_name = 'term-project3280'
    has_existing_parquet = False
    has_user_data_csv = False
    has_top_artists_csv = False
    response = s3.list_objects(Bucket=bucket_name)
    for obj in response['Contents']:
        if obj['Key'].endswith('.parquet') and obj['Key'].startswith('processed_parquet'):
            has_existing_parquet = True
            break
        if obj['Key'].endswith('.csv') and obj['Key'].startswith('user_data/user_data'):
            has_user_data_csv = True
        elif obj['Key'].endswith('.csv') and obj['Key'].startswith('user_data/user_top_artists'):
            has_top_artists_csv = True

    #dont do anything is data is not enough
    if has_existing_parquet != True:
        if (has_user_data_csv == False) or (has_top_artists_csv == False):
            print("Not enough data to start the pipeline")
            return {
                "statusCode": 200,
                "body": "Not starting due to insufficient data"
            }
        
    try:
        print(f"✅Starting Glue job: {glue_job_name}")

        response = glue.start_job_run(
            JobName=glue_job_name
        )

        job_run_id = response["JobRunId"]
        print(f"✅Started Glue JobRunId: {job_run_id}") 

    except Exception as e:
        print(f"❌Error starting Glue job: {str(e)}")
        return {
            "statusCode": 500,
            "body": f"Error: {str(e)}"
        }

